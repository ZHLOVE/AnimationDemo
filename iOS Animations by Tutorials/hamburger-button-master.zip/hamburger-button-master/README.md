# A Hamburger button transition

<p align="center">
    <img src="http://robb.is/img/hamburger-button.gif">
</p>

I wrote a [blog post](http://robb.is/working-on/a-hamburger-button-transition/)
on how this works. Inspired by a [dribbble shot by
Creativedash](https://dribbble.com/shots/1623679-Open-Close).
